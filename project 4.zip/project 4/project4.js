/*

1. reading the jQuery code was somewhat easier than reading the pure javascript code 
mainly beacause the jquery was much more compressed. The lengths of code were about the same, however jquery is better to use to understand what is happening 
in the document object model

2. this jQuery program turned out to be about the same length as the javascript program

3. jquery is known to make javascript much shorter, however the javascript and jquery versions of the project were about the same length beacause ther were mostly subtle changes
that were made, because a vast majority of this project uses logical operators and methods that cannot be "converted" to jquery, or no such jquery keywords or tools exist

*/

var imgArray = new Array();
	
	image1 = new Image();
	image1.src = "images/josie1.JPG";
	
	image2 = new Image();
	image2.src = "images/josie2.JPG";
	
	image3 = new Image();
	image3.src = "images/josie3.JPG";
	
	image4 = new Image();
	image4.src = "images/josie4.JPG";
	
	image5 = new Image();
	image5.src = "images/josie5.JPG";
	
	image6 = new Image();
	image6.src = "images/josie6.JPG";


var imgArray = [image1, image2, image3, image4, image5, image6];

var index = 0;

//var the_image = document.getElementById("main-image");
//the_image.src = images[0];

$("button#random").click(function(){
    index = (Math.floor(Math.random()*6));
	$("img#slideshow").attr("src", imgArray[index].src);
});

$("button#next").click(function(){
	if(index == 5){
		index = 0;
	}	
	else{
		index++;
	}	
	$("img#slideshow").attr("src", imgArray[index].src);
});

function startTime() {
	  var today = new Date();
	  var h = today.getHours();
	  var m = today.getMinutes();
	  var s = today.getSeconds();
	  m = checkTime(m);
	  s = checkTime(s);
	  var myTime = h + ":" + m + ":" + s;
	  document.getElementById('time').textContent = "The current time is: " + myTime;
	  var t = setTimeout(startTime, 60000);
	}
	

function checkTime(i) {
	if (i < 10) {
		{i = "0" + i};  // add zero in front of numbers < 10
	}
	return i;
	}


$(document).ready(function() {
	var today = new Date(); 
	var hourNow = today.getHours(); 
	if (hourNow > 0 && hourNow < 3) { 
		$("img#time_image").attr("src", imgArray[1].src);
	}
	else if (hourNow > 3 && hourNow < 7) { 
		$("img#time_image").attr("src", imgArray[2].src);
	}
	else if (hourNow > 7 && hourNow < 11) { 
		$("img#time_image").attr("src", imgArray[3].src);
	}
	else if (hourNow > 11 && hourNow < 15) { 
		$("img#time_image").attr("src", imgArray[4].src);
	}
	else if (hourNow > 15 && hourNow < 19) { 
		$("img#time_image").attr("src", imgArray[4].src);
	}
	else if (hourNow > 19 && hourNow < 23) {
		$("img#time_image").attr("src", imgArray[5].src);
	}
});

//window.onload = time_picture();
window.onload = startTime();
window.onload = checkTime(); 
